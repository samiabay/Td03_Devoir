#include<iostream>
#include<algorithm> 
#include <iterator> 
#include<list>
using namespace std ;


int main(){
	list<string> l;
 	string st;
 	int n, i;
 	
 	cout << "Le nombre des personnes a entrer: ";
 	cin >> n;
 	
	for(i=0; i<n; i++){
		cout << "Veuillez saisir le nom: ";
 		cin >> st;
 		l.push_back(st);
 	
  		cout << "Veuillez saisir le prenom: ";
 		cin >> st;
 		l.push_back(st);

		cout << "Veuillez saisir l'age: ";
 		cin >> st;
	}

 	l.sort(greater <string>());

    list<string>:: iterator it;
    for(it=l.begin(); it!=l.end(); ++it) {
        cout << *it << " ";
    }
	return 0;
}