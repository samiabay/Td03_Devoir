#include <iostream>
#include <iterator>
#include <set>
using namespace std;

void recherche(set<int, greater<int> > s, int n){
    set<int, greater<int> >:: iterator it;
    it = s.begin();
    if(s.count(n))
        cout<<"la valeur donnee est presente dans le set"<<endl;
    else 
        cout <<"la valeur donnee n'est pas presente dans le set"<<endl;
}

int main(){
	int i, n;
	set<int, greater<int> > s;
	
	for (i=0; i<100; ++i){
        s.insert(i+1);
    }

	cout << "Veuillez saisir la valeur recherchee: ";
    cin >> n;
    recherche(s, n);
	
	return 0;
}