#include<iostream>
using namespace std;

class complexe{
    private:
    	double reelle;
    	double imaginaire;

    public:
    	complexe(double reelle, double imaginaire);
   		void operator + (complexe);
   		void operator - (complexe);
   		void operator * (complexe);
};

complexe ::complexe(double reelle, double imaginaire){
    this->reelle = reelle;
    this->imaginaire = imaginaire;
}

void  complexe::operator+(complexe c){
    int r, i;
    r = reelle + c.reelle;
    i = imaginaire + c.imaginaire;
    cout << "Le resultat de l'addition des deux nombres est  " << r << " + " << i << "i" << endl;
}

void  complexe::operator-(complexe c){
    int r, i;
    r = reelle - c.reelle;
    i = imaginaire - c.imaginaire;
    cout << "Le resultat de la sousraction des deux nombres est  " << r << " + " << i << "i" << endl;
}

void  complexe::operator*(complexe c){
    int r, i;
    r = reelle*c.reelle - imaginaire*c.imaginaire;             
    i = imaginaire*c.reelle + reelle*c.imaginaire;
    cout << "Le resultat de la multiplication des deux nombres est  " << r << " + " << i << "i" << endl;
}

int main(){
    complexe c1(2,3), c2(1,6);
    c1 + c2;
    c1 - c2;
    c1 * c2;

    return 0;
}