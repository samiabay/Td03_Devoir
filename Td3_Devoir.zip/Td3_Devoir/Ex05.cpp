#include <iostream>
#include <stdexcept>
#include <exception>
using namespace std;

class Excep1 : public exception{
	public:
	const char * what() const throw(){
		return "Indice superieur a la taille du tableau!\n";
	}
};

class Excep2 : public exception{
	public:
	const char * what() const throw(){
		return "Tentative de division par zero!\n";
	}
};

class Test{
	public:
		static int tableau[];
	public:
		static int division(int indice, int diviseur){
			return tableau[indice]/diviseur;
		}
};

int Test::tableau[] = {17, 12, 15, 38, 29, 157, 89, -22, 0, 5};

int main(){
	int x, y;
	try {
		cout << "Entrez l'indice de l'entier a diviser: " << endl;
		cin >> x;
		
		if(x >= 10){
			Excep1 z;
			throw z;
		}	
	
		cout << "Entrez le diviseur: " << endl;
		cin >> y;
		
		if(y == 0){
			Excep2 z;
			throw z;
		} else {
			cout << "Le resultat de la division est: "<< endl;
			cout <<Test::division(x,y) << endl;
		}	
	}
	catch(exception& e){
		cout << e.what();
	}
	
	return 0;
}